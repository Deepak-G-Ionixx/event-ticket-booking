package com.ionixx.eventticketbooking.security;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.ionixx.eventticketbooking.entity.Role;

@Configuration
@EnableWebSecurity
@EnableConfigurationProperties(JwtProperties.class)
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            JwtService jwtService,
            RestAuthenticationEntryPoint authenticationEntryPoint,
            RestAccessDeniedHandler accessDeniedHandler) throws Exception {

        http
                // This is a stateless REST API; it does not use cookie-based sessions.
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // Disable browser login forms and HTTP Basic authentication.
                .formLogin(AbstractHttpConfigurer::disable)
                .httpBasic(AbstractHttpConfigurer::disable)
                .logout(AbstractHttpConfigurer::disable)

                // 401 means unauthenticated; 403 means authenticated but forbidden.
                .exceptionHandling(exceptions -> exceptions
                        .authenticationEntryPoint(authenticationEntryPoint)
                        .accessDeniedHandler(accessDeniedHandler))

                .authorizeHttpRequests(auth -> auth

                        // -------------------------------------------------
                        // Public authentication endpoints.
                        // A JWT is not required for these routes.
                        // -------------------------------------------------
                        .requestMatchers(
                                HttpMethod.POST,
                                "/auth/login",
                                "/auth/register",
                                "/auth/forgot-password",
                                "/auth/reset-password"
                        ).permitAll()

                        // Permit Swagger UI and its supporting static resources.
                        .requestMatchers(
                                "/swagger-ui.html",
                                "/swagger-ui/**"
                        ).permitAll()

                        // Permit OpenAPI JSON/YAML and Swagger configuration.
                        .requestMatchers(
                                "/v3/api-docs",
                                "/v3/api-docs/**",
                                "/v3/api-docs.yaml"
                        ).permitAll()

                        // Permit the default error endpoint.
                        .requestMatchers("/error").permitAll()

                        // Permit application health checks.
                        .requestMatchers(
                                "/actuator/health",
                                "/actuator/health/**"
                        ).permitAll()

                        // -------------------------------------------------
                        // Role-restricted endpoints.
                        // -------------------------------------------------

                        // Only an ORGANISER can create an event.
                        .requestMatchers(HttpMethod.POST, "/api/events")
                        .hasRole(Role.ORGANISER.name())

                        // Only a CUSTOMER can create a booking.
                        .requestMatchers(HttpMethod.POST, "/api/bookings")
                        .hasRole(Role.CUSTOMER.name())

                        // Only an ORGANISER can change or delete an event.
                        // The service then checks that the organiser OWNS it.
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/events/*")
                        .hasRole(Role.ORGANISER.name())
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/api/events/*")
                        .hasRole(Role.ORGANISER.name())

                        // The bookable-event list is for customers. Organisers
                        // use /api/events/mine for their own events.
                        .requestMatchers(HttpMethod.GET, "/api/events")
                        .hasRole(Role.CUSTOMER.name())

                        // "My events" belongs to organisers, "my bookings" to customers.
                        .requestMatchers(HttpMethod.GET, "/api/events/mine")
                        .hasRole(Role.ORGANISER.name())
                        .requestMatchers(HttpMethod.GET, "/api/bookings/mine")
                        .hasRole(Role.CUSTOMER.name())

                        // Booking lists and summaries show other people's details and
                        // revenue, so only organisers may call them. The service then
                        // checks that the organiser owns the event.
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/events/*/bookings",
                                "/api/events/*/summary")
                        .hasRole(Role.ORGANISER.name())

                        // All remaining endpoints require a valid JWT.
                        .anyRequest().authenticated())

                // Run JWT authentication inside Spring Security's filter chain.
                // Do not add @Component to JwtAuthenticationFilter because this
                // configuration creates the filter instance directly.
                .addFilterBefore(
                        new JwtAuthenticationFilter(jwtService),
                        UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // BCrypt hashes passwords before they are stored in PostgreSQL.
        return new BCryptPasswordEncoder();
    }

    // Builds the AuthenticationManager using the configured user service
    // and password encoder. AuthService uses it during login.
    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }
}
